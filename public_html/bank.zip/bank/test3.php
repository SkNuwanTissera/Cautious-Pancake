<!DOCTYPE html>
<html lang="en">
<head>
  <title>online</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron">
<div class="container">
  <h2>ONLINE RECORDS</h2>
  <button type="button"onclick="window.location.href = 'ping.php';" class="btn btn-default">Add New Records</button><br><br>
  <button type="button"onclick="window.location.href = 'employ.php';" class="btn btn-primary">Add new employee</button><br><br>
  <button type="button" onclick="window.location.href = 'new_customer.php';"class="btn btn-success">Add new customer</button><br><br>
  
  <button type="button"onclick="window.location.href = 'recodes.php';" class="btn btn-warning">Viwe all Records</button><br><br>
  <button type="button" onclick="window.location.href = 'edite.php';"class="btn btn-danger"> Add new location</button><br><br>
<button type="button" onclick="window.location.href = 'index.php';"class="btn btn-danger">Back</button><br><br>
 <!-- <button type="button" onclick="window.location.href = 'edite.php';"class="btn btn-danger"></button><br><br>
  <button type="button" onclick="window.location.href = 'edite.php';"class="btn btn-danger"></button>

</div>
</div>
</body>
</html>
