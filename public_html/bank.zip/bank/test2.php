<!DOCTYPE html>
<html>
<body>

<p>
Depending on browser support:<br>
A date picker can pop-up when you enter the input field.
</p>

<form action="action_page.php">
  Birthday:
  <input type="date" name="bday">
  <input type="submit">
</form>

<p><strong>Note:</strong> type="date" is not supported in Internet Explorer 10 and earlier versions.</p>
<form action="action_page.php">
  Birthday:
  <input type="date" name="bday">
  <input type="submit">
</form>
</body>
</html>