<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Record</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


</head>
<body>
    
          <style>
              
img {
    float: right;
    margin: 1px;
    padding: 1px;
    max-width:100%;
    height:100%;
    border: 0px solid black;
    position: absolute;
    left: 0px;
    top: 0px;
    z-index: -1;
}
</style>

<div class="img">
<div class="container text-center">
        
            <h2>ONLINE UPDATE</h2>
<form action="test3.php"method="post" >
<img class="img" src ='image/BDM5_booting_gif.gif' >
<input type="text" name="username"value="">
<br>
<br>
<input type="password" name="password"value="">
<br>
<br>
<input type="submit" name="save" value="LOGIN" />

        </div>
</div>
</form>
</body>
</html>